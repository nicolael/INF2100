#include <stdio.h>
void write_char (int c)
{
	printf("%c", c); 
}
void write_int (int n)
{
	printf("%d", n); 
}
void write_string (char *s)
{
	printf("%s", s); 
}